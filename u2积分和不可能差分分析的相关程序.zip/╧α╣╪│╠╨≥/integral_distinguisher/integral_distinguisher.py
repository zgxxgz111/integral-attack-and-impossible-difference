from u2 import U2

if __name__ == "__main__":

    ROUND = int(input("Input the number of round :"))
    ACTIVEBITS = int(input("Input the number of activebits:"))
    u2 = U2(ROUND,ACTIVEBITS)

    u2.CreateObjectiveFunction()

    u2.MakeModel()
    u2.SolveModel()












    
