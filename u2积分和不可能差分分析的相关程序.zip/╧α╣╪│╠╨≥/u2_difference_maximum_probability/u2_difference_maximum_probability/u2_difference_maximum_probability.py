from gurobipy import *
import time

reduce_inequalities = [[0, -1, -1, -1, -2, -2, -2, -1, -3, 10],  # 约束present的S盒的约简后的不等式组，原本是11维，
[4, 2, 2, 5, 1, 4, 1, 6, 8, -12],                                # 但是最后1维都是0，所以省去了
[3, 4, 4, 2, 2, 0, 2, 1, -1, -5],
[-1, -8, 7, -3, -2, 4, -2, -9, 11, 14],
[-5, 4, -2, -3, 3, 1, -3, -1, 4, 7],
[0, -1, -1, 1, 2, 0, 2, 0, -1, 1],
[-1, 1, -2, 2, -5, -4, 3, 1, 5, 6],
[1, -5, 2, -2, 3, -5, -3, 1, 4, 9],
[3, 2, -5, -3, -2, -1, 3, -1, 2, 7],
[1, 2, 2, 0, -1, 0, -1, 0, -1, 1],
[-3, -2, 1, -2, -2, -1, 3, -1, 1, 7],
[1, -1, -1, 1, -1, 0, -1, -1, -2, 5],
[-2, -1, -1, -2, 1, 1, 0, 1, -1, 5],
[-8, -4, -4, 6, -1, 2, -1, 0, 7, 10],
[0, 1, 1, -1, 1, -1, 1, -1, -1, 2],
[3, 2, 1, 0, 2, 4, 2, 4, 1, -6],
[0, 3, -3, 1, -1, -1, -2, -2, 1, 6],
[1, -2, 3, 2, 1, 3, -2, -2, 1, 2],
[0, -3, -3, -2, -1, 2, -1, -2, -1, 10],
[-1, 2, 2, 5, 1, -1, 1, 3, 1, -3],
[-1, 0, -1, -1, -1, 0, 1, 1, -1, 4],
[0, 2, -2, 1, -1, 1, 0, -1, 1, 2],
[3, 1, 1, -3, -2, -3, -2, 1, -1, 7],
[-3, -1, 2, -2, -2, 0, 2, -1, 2, 5],
[0, -2, 2, 1, -2, -1, 0, -1, 1, 4]]


def objective_function():       # 将目标函数写入 .lp 文件
	fileobj = open( filename_model,"a" )	
	fileobj.write( "Minimize\n" )
	eqn = []
	for i in range( round ):
		for j in range(4):    # j 表示第 j 个 S 层
			for k in range(4):    # k 表示第 k 个 S 盒
				eqn.append( "u_" + str(i+1) + "_" + str(j+1) + "_" + str( 6*(k+1)-2 ) + " + " + "2 " + "u_" + str(i+1) + "_" + str(j+1) + "_" + str( 6*(k+1)-1 ))

		for j in range(4):    # j 表示第 j 个 S 层
			for k in range(4):    # k 表示第 k 个 S 盒
				eqn.append( "v_" + str(i+1) + "_" + str(j+1) + "_" + str( 6*(k+1)-2 ) + " + " + "2 " + "v_" + str(i+1) + "_" + str(j+1) + "_" + str( 6*(k+1)-1 ))					

	temp = " + ".join( eqn )
	fileobj.write( temp )
	fileobj.write( "\n" )
	fileobj.close()


def CreateVariables1( n,s ):          #创造第n圈的变元,    0,1,……,round
    array = []
    for i in range( 16 ):
        array.append( s + "_" + str(n) + "_" + str(i) )
    return array


def CreateVariables2(i,j,s):         # 创造第i圈F函数的变元
    array = []                       # 第 j 个 S 层
    for k in range( 24 ):              
        array.append( s + "_" + str(i) + "_" + str(j) + "_" + str( k ) )
    return array


def VariableBinary():   #设置所有变元为二元变量
    fileobj = open( filename_model,"a" )
    fileobj.write( "Binary\n" )

    for i in range( round+1 ):
        for j in range(16):
            fileobj.write("x_" + str(i) + "_" + str(j))
            fileobj.write("\n")

        for j in range( 16 ):
            fileobj.write("y_" + str(i) + "_" + str(j))
            fileobj.write("\n")

        for j in range( 16 ):
            fileobj.write("z_" + str(i) + "_" + str(j))
            fileobj.write("\n")

        for j in range( 16 ):
            fileobj.write("w_" + str(i) + "_" + str(j))
            fileobj.write("\n")
            
    for i in range( 1,round + 1 ):
        for j in range( 5 ):
            for k in range( 16 ):
                fileobj.write("u_" + str(i) + "_" + str(j) + "_" + str(k) )
                fileobj.write("\n")
    for i in range( 1,round+1 ):
        for j in range( 5 ):
            for k in range( 16 ):
                fileobj.write("v_" + str(i) + "_" + str(j) + "_" + str(k) )
                fileobj.write( "\n" )

    fileobj.close()


def LinearLayer(variableoutx,variableouty,variableoutz,variableoutw):  #TYPE II 结构的置换
    temp1 = ["" for i in range(16)]
    temp2 = ["" for i in range(16)]
    temp3 = ["" for i in range(16)]
    temp4 = ["" for i in range(16)]
    for i in range(16):
        temp1[i] = variableouty[i]
        temp2[i] = variableoutz[i]
        temp3[i] = variableoutw[i]
        temp4[i] = variableoutx[i]
    return temp1,temp2,temp3,temp4


def sbox_constraints( n,o,p,variable1,variable2 ):         #产生一个 s 层，共 4 个 s 盒的约束条件 ; n表示第n圈，o表示左右，
    fileobj = open(filename_model,"a") 

    for i in range( 4 ):      # i表示有4个S盒
        equ = []
        for j in range( 25 ):  # 每个带概率的 4 比特S盒有 25 个不等式来刻画
            for k in range( 4 ):
                equ.append( str(reduce_inequalities[j][k]) + " " + variable1[(3-k)+i*4] )
            for k in range( 4,8 ):
                equ.append( str(reduce_inequalities[j][k]) + " " + variable2[(7-k)+i*6] )
            for k in range( 4,6 ):
                equ.append( str(reduce_inequalities[j][ k + 4 ]) + " " + variable2[( k )+i*6] )
            equ1 = " + ".join( equ )
            equ1 = equ1.replace("+ -","- ") # -后面应该有个空格？yes
            equ1 = equ1 + " >= 0"
            fileobj.write( equ1 )
            fileobj.write( "\n" )
            equ = []
            
    fileobj.close()


def round_function_constraints( i,variableinx,variableiny,variableinz,variableinw,variableoutx,variableouty,variableoutz,variableoutw ):  #产生一圈的约束条件
    variableu1 = [ "" for i in range(16) ]
    for j in range( 16 ):
        variableu1[j] = variableinx[j]       # variableu1 , variableinx , variableoutx表示 16 维向量 ，variableu2 表示 24 维向量
        variableoutx[j] = variableinx[j]
    variableu2 = CreateVariables2(i,1,"u")   # 第一个参数 i 表示产生第 i 圈的变元；第二个参数 j 表示产生第 j 轮S-P的变元

    variablev1 = [ "" for i in range(16) ]
    for j in range( 16 ):
        variablev1[j] = variableinz[j]
        variableoutz[j] = variableinz[j]
    variablev2 = CreateVariables2(i,1,"v")   # 第一个参数 i 表示产生第 i 圈的变元；第二个参数 j 表示产生第 j 轮S-P的变元


    for j in range(4):  # j 表示每个 F 函数中有 4 个 S-P 结构 ,   这是左边的 F 函数
        sbox_constraints( i,0,j,variableu1,variableu2 )  # 每一层 4 个s盒产生的约束条件             
        variableu1[0] = variableu2[12];variableu1[1] = variableu2[7];variableu1[2] = variableu2[2];variableu1[3] = variableu2[21];
        variableu1[4] = variableu2[6];variableu1[5] = variableu2[1];variableu1[6] = variableu2[20];variableu1[7] = variableu2[15];
        variableu1[8] = variableu2[0];variableu1[9] = variableu2[19];variableu1[10] = variableu2[14];variableu1[11] = variableu2[9];
        variableu1[12] = variableu2[18];variableu1[13] = variableu2[13];variableu1[14] = variableu2[8];variableu1[15] = variableu2[3]
        variableu2 = CreateVariables2(i,j+2,"u")

    for j in range(4):  # j 表示每个 F 函数中有 4 个 S-P 结构 ,   这是右边的 F 函数
        sbox_constraints( i,1,j,variablev1,variablev2 )
        variablev1[0] = variablev2[12];variablev1[1] = variablev2[7];variablev1[2] = variablev2[2];variablev1[3] = variablev2[21];
        variablev1[4] = variablev2[6];variablev1[5] = variablev2[1];variablev1[6] = variablev2[20];variablev1[7] = variablev2[15];
        variablev1[8] = variablev2[0];variablev1[9] = variablev2[19];variablev1[10] = variablev2[14];variablev1[11] = variablev2[9];
        variablev1[12] = variablev2[18];variablev1[13] = variablev2[13];variablev1[14] = variablev2[8];variablev1[15] = variablev2[3]
        variablev2 = CreateVariables2(i,j+2,"v")

    fileobj = open( filename_model,"a" )  # 这一段描写的是 异或操作 的约束条件                  
    for k in range( 16 ):        
        fileobj.write( variableu1[k] + " + " + variableiny[k]+ " + " + variableouty[k] + " - " + "2" + " " + "d_" + str(i) + "_" + "0" + "_" + str(k) + " >= 0" )
        fileobj.write( "\n" )

        fileobj.write( variableu1[k] + " + " + variableiny[k]+ " + " + variableouty[k] + " <= " + "2" )
        fileobj.write( "\n" )

        fileobj.write( "d_" + str(i) + "_" + "0" + "_" + str(k) + " - "  +  variableu1[k]+ " >= 0" )
        fileobj.write( "\n" )

        fileobj.write( "d_" + str(i) + "_" + "0" + "_" + str(k) + " - "  +  variableiny[k]+  " >= 0" )
        fileobj.write( "\n" )

        fileobj.write( "d_" + str(i) + "_" + "0" + "_" + str(k) + " - "  + variableouty[k] + " >= 0" )
        fileobj.write( "\n" )

    for k in range( 16 ):
        fileobj.write( variablev1[k] + " + " + variableinw[k]+ " + " + variableoutw[k] + " - " + "2" + " " + "d_" + str(i) + "_" + "1" + "_" + str(k) + " >= 0")
        fileobj.write( "\n" )

        fileobj.write( variablev1[k] + " + " + variableinw[k]+ " + " + variableoutw[k] + " <= " + "2" )
        fileobj.write( "\n" )

        fileobj.write( "d_" + str(i) + "_" + "1" + "_" + str(k) + " - "  +  variablev1[k]+ " >= 0" )
        fileobj.write( "\n" )

        fileobj.write( "d_" + str(i) + "_" + "1" + "_" + str(k) + " - "  +  variableinw[k]+  " >= 0" )
        fileobj.write( "\n" )

        fileobj.write( "d_" + str(i) + "_" + "1" + "_" + str(k) + " - "  + variableoutw[k] + " >= 0")
        fileobj.write( "\n" )

    fileobj.close()


def constraints():         #产生更新n圈的约束条件
    fileobj = open( filename_model, "a" )
    fileobj.write( "Subject To \n" )
    fileobj.close()
    variableinx = CreateVariables1( 0,"x" )           #创造第0圈的变元
    variableiny = CreateVariables1( 0,"y" )
    variableinz = CreateVariables1( 0,"z" )
    variableinw = CreateVariables1( 0,"w" )

    variableoutx = CreateVariables1( 1,"x" )           #创造第1圈的变元
    variableouty = CreateVariables1( 1,"y" )
    variableoutz = CreateVariables1( 1,"z" )
    variableoutw = CreateVariables1( 1,"w" )

    if round == 1:
        round_function_constraints( 1,variableinx,variableiny,variableinz,variableinw,variableoutx,variableouty,variableoutz,variableoutw )   #产生圈函数算法的约束条件，包含四圈的S盒与P盒
    else :
        round_function_constraints( 1,variableinx,variableiny,variableinz,variableinw,variableoutx,variableouty,variableoutz,variableoutw )   #产生圈函数算法的约束条件，包含四圈的S盒与P盒
        for i in range(1,round):
            variableinx,variableiny,variableinz,variableinw = LinearLayer(variableoutx,variableouty,variableoutz,variableoutw)     #产生大置换的约束条件、
            variableoutx = CreateVariables1(i+1,"x")           #创造第i+1圈的变元
            variableouty = CreateVariables1(i+1,"y")
            variableoutz = CreateVariables1(i+1,"z")
            variableoutw = CreateVariables1(i+1,"w")
            round_function_constraints(i+1,variableinx,variableiny,variableinz,variableinw,variableoutx,variableouty,variableoutz,variableoutw)


def extra_constraints():
    variableinx = CreateVariables1(0,"x")           #创造第0圈的变元
    variableiny = CreateVariables1(0,"y")
    variableinz = CreateVariables1(0,"z")
    variableinw = CreateVariables1(0,"w")
    temp = []

    for i in range( 16 ):            #添加关于x的变元
        temp.append( variableinx[i] ) 
    for i in range( 16 ):            #添加关于y的变元
        temp.append( variableiny[i] )
    for i in range( 16 ):            #添加关于z的变元
        temp.append( variableinz[i] )
    for i in range( 16 ):            #添加关于w的变元
        temp.append( variableinw[i] )
    temp1 = " + ".join( temp )
    temp1 = temp1 + " >= 1"
    fileobj = open( filename_model,"a" )
    fileobj.write( temp1 )
    fileobj.write( "\n" )
    fileobj.close()



def binary_variables( round ):
    fileobj = open( filename_model,"a" )
    fileobj.write( "Binary\n" )
    for i in range( round + 1 ):                    # 添加每一圈的变元
        variableinx = CreateVariables1( i,"x" )           
        variableiny = CreateVariables1( i,"y" )
        variableinz = CreateVariables1( i,"z" )
        variableinw = CreateVariables1( i,"w" )
        for j in range(16):
            fileobj.write( variableinx[j] )
            fileobj.write("\n")
        for j in range(16):
            fileobj.write( variableiny[j] )
            fileobj.write("\n")
        for j in range(16):
            fileobj.write( variableinz[j] )
            fileobj.write("\n")
        for j in range(16):
            fileobj.write( variableinw[j] )
            fileobj.write("\n")
    
    for i in range(round):                       # 添加每一圈的F函数的变元
        for j in range(4):
            for k in range(24):
                fileobj.write( "u_" + str(i+1) + "_" + str(j+1) + "_" + str(k) )
                fileobj.write("\n")
    for i in range(round):                       # 添加每一圈的F函数的变元
        for j in range(4):
            for k in range(24):
                fileobj.write( "v_" + str(i+1) + "_" + str(j+1) + "_" + str(k) )
                fileobj.write("\n")

    for i in range( round ):                       #添加 异或 操作的中间变元  d_i_0/1_0,1,…,15
        for k in range(16):
            fileobj.write( "d_" + str(i+1) + "_" + "0" + "_" + str(k) )
            fileobj.write( "\n" )
    for i in range( round ):
        for k in range(16):
            fileobj.write( "d_" + str(i+1) + "_" + "1" + "_" + str(k) )
            fileobj.write( "\n" )

    fileobj.write("END")


if __name__ == "__main__":
	round = int(input("请输入圈数："))
	filename_model = "u2_difference_maximum_probability_" + str(round) + ".lp"
	filename_results = "u2_difference_maximum_probability_" + str(round) + ".txt"

	fileobj = open(filename_model,"w")
	fileobj.close()
	fileobj = open(filename_results,"w")
	fileobj.close()

	objective_function()       # 产生目标函数
	constraints()              # 产生约束条件
	extra_constraints()        # 产生约束大于 0 的约束条件	
	binary_variables( round )  # 令每个变元都为二进制变元


	time_start = time.time()
	m = read( filename_model )      # 读取模型
	m.Params.MIPFocus = 2
	m.optimize()


	if m.Status == 2 :
		fileobj = open(filename_results,"a")

		obj = m.getObjective()
		fileobj.write(  str( obj.getValue() )  )
		fileobj.write("\n")

		#x = m.getVars()
		#fileobj.write( str( x ) )

		for v in m.getVars():
			fileobj.write( v.varName )
			fileobj.write( " " )
			fileobj.write( str( v.x ) )
			fileobj.write( "\n" )

		time_end = time.time()
		fileobj.write( ("Time used =" + str(time_end - time_start)) )

		fileobj.close()


