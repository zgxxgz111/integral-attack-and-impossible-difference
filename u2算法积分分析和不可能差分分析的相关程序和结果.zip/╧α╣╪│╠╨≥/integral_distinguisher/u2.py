from gurobipy import *

import time

class U2:
    def __init__(self, Round, Activebits):
        self.Round = Round
        self.Activebits = Activebits
        self.blocksize = 64
        self.filename_model = "U2_" + str(self.Round) + "_" + str(self.Activebits) + ".lp"
        self.filename_result = "Result" + str(self.Round) + "_" + str(self.Activebits) + ".txt"
        fileobj = open(self.filename_model,"w")
        fileobj.close()
        fileobj = open(self.filename_result,"w")
        fileobj.close()


    # Linear inequalities for the PRESENT Sbox
    S_T = [[1, 1, 1, 1, -1, -1, -1, -1, 0],\
    [0, -1, -1, -2, 1, 0, 1, -1, 3],\
    [0, -1, -1, -2, 4, 3, 4, 2, 0],\
    [-2, -1, -1, 0, 2, 2, 2, 1, 1],\
    [-2, -1, -1, 0, 3, 3, 3, 2, 0],\
    [0, 0, 0, 0, -1, 1, -1, 1, 1],\
    [-2, -2, -2, -4, 1, 4, 1, -3, 7],\
    [1, 1, 1, 1, -2, -2, 1, -2, 1],\
    [0, -4, -4, -2, 1, -3, 1, 2, 9],\
    [0, 0, 0, -2, -1, -1, -1, 2, 3],\
    [0, 0, 0, 1, 1, -1, -2, -1, 2]]


    def CreateObjectiveFunction(self):     # 创造目标函数
        fileobj = open(self.filename_model,"a")
        fileobj.write('Minimize\n')
        eqn = []
        for i in range(16):
            eqn.append( "x_" + str(self.Round) + "_" + str(i) )
        temp = " + ".join(eqn)
        fileobj.write(temp)
        fileobj.write(" + ")

        eqn=[]
        for i in range(16):
            eqn.append( "y_" + str(self.Round) + "_" + str(i) )
        temp = " + ".join(eqn)
        fileobj.write( temp )
        fileobj.write( " + " )

        eqn=[]
        for i in range(16):
            eqn.append( "z_" + str(self.Round) + "_" + str(i) )
        temp = " + ".join( eqn )
        fileobj.write( temp )
        fileobj.write( " + " )

        eqn=[]
        for i in range(16):
            eqn.append( "w_" + str(self.Round) + "_" + str(i) )
        temp = " + ".join( eqn )
        fileobj.write( temp )

        fileobj.write( "\n" )
        fileobj.close()


    @staticmethod
    def CreateVariables1(n,s):          #创造第n圈的变元
        array = []
        for i in range(16):
            array.append(s + "_" + str(n) + "_" + str(i))
        return array


    @staticmethod
    def CreateVariables2(i,j,s):         #创造第i圈F函数的变元
        array = []
        for k in range(16):
            array.append(s + "_" + str(i) + "_" + str(j) + "_" + str(k))
        return array


    @staticmethod
    def LinearLayer(variableoutx,variableouty,variableoutz,variableoutw):  #TYPE II 结构的置换
        temp1 = [""for i in range(16)]
        temp2 = [""for i in range(16)]
        temp3 = [""for i in range(16)]
        temp4 = [""for i in range(16)]
        for i in range(16):
            temp1[i] = variableouty[i]
            temp2[i] = variableoutz[i]
            temp3[i] = variableoutw[i]
            temp4[i] = variableoutx[i]
        return temp1,temp2,temp3,temp4


    def copy_function_constraints(self,variablein,variable,variableout):     #产生复制函数的约束条件
        fileobj = open(self.filename_model,"a")
        for i in range(16):
            fileobj.write(variablein[i] + " - " + variable[i] + " - " + variableout[i] + " = " + "0")
            fileobj.write("\n")
        fileobj.close()
        

    def sbox_constraints(self,variable1,variable2):         #产生s盒的约束条件
        fileobj = open(self.filename_model,"a")
        for i in range(4):      # i表示有4个S盒
            equ=[]
            for j in range(11):  #每个4比特S盒有11个不等式来刻画
                for k in range(4):
                    equ.append( str(U2.S_T[j][k]) + " " + variable1[(3-k)+i*4] )
                for k in range(4,8):
                    equ.append( str(U2.S_T[j][k]) + " " + variable2[(7-k)+i*4] )
                equ1 = " + ".join( equ )
                equ1 = equ1.replace("+ -","- ") # -后面应该有个空格？yes
                equ1 = equ1 + " >= " + str(-U2.S_T[j][8])
                equ1 = equ1.replace("--","")
                fileobj.write(equ1)
                fileobj.write("\n")
                equ=[]
        fileobj.close()


    def round_function_constraints(self,i,variableinx,variableiny,variableinz,variableinw,variableoutx,variableouty,variableoutz,variableoutw):  #产生一圈的约束条件
        variableu1 = U2.CreateVariables2(i,0,"u")   #第一个参数 i 表示产生第 i 圈的变元；第二个参数 j 表示产生第 j 轮S-P的变元
        variableu2 = U2.CreateVariables2(i,1,"u")
        variablev1 = U2.CreateVariables2(i,0,"v")
        variablev2 = U2.CreateVariables2(i,1,"v")
        self.copy_function_constraints(variableinx, variableu1, variableoutx)
        self.copy_function_constraints(variableinz, variablev1, variableoutz)

        for j in range(4):  # j表示每个 F 函数中有 4 个 S-P 结构
            self.sbox_constraints(variableu1,variableu2)  #每轮4个s盒产生的约束条件
            variableu1[0] = variableu2[8];variableu1[1] = variableu2[5];variableu1[2] = variableu2[2];variableu1[3] = variableu2[15];
            variableu1[4] = variableu2[4];variableu1[5] = variableu2[1];variableu1[6] = variableu2[14];variableu1[7] = variableu2[11];
            variableu1[8] = variableu2[0];variableu1[9] = variableu2[13];variableu1[10] = variableu2[10];variableu1[11] = variableu2[7];
            variableu1[12] = variableu2[12];variableu1[13] = variableu2[9];variableu1[14] = variableu2[6];variableu1[15] = variableu2[3]
            variableu2 = U2.CreateVariables2(i,j+2,"u")

        for j in range(4):
            self.sbox_constraints(variablev1,variablev2)
            variablev1[0] = variablev2[8];variablev1[1] = variablev2[5];variablev1[2] = variablev2[2];variablev1[3] = variablev2[15];
            variablev1[4] = variablev2[4];variablev1[5] = variablev2[1];variablev1[6] = variablev2[14];variablev1[7] = variablev2[11];
            variablev1[8] = variablev2[0];variablev1[9] = variablev2[13];variablev1[10] = variablev2[10];variablev1[11] = variablev2[7];
            variablev1[12] = variablev2[12];variablev1[13] = variablev2[9];variablev1[14] = variablev2[6];variablev1[15] = variablev2[3]
            variablev2 = U2.CreateVariables2(i,j+2,"v")

        fileobj = open(self.filename_model,"a")                   
        for k in range(16): 
            fileobj.write( variableu1[k] + " + " + variableiny[k]+ " - " + variableouty[k] + " = " + "0" )
            fileobj.write("\n")
            fileobj.write( variablev1[k] + " + " + variableinw[k]+ " - " + variableoutw[k] + " = " + "0" )
            fileobj.write("\n")
        fileobj.close()


    def Constraint(self):         #产生更新n圈的约束条件
        fileobj = open(self.filename_model, "a")
        fileobj.write("Subject To \n")
        fileobj.close()
        variableinx = U2.CreateVariables1(0,"x")           #创造第0圈的变元
        variableiny = U2.CreateVariables1(0,"y")
        variableinz = U2.CreateVariables1(0,"z")
        variableinw = U2.CreateVariables1(0,"w")

        #variableu1 = U2.CreateVariables2(0,0,"u")
        #variableu2 = U2.CreateVariables2(0,0,"u")

        variableoutx = U2.CreateVariables1(1,"x")           #创造第1圈的变元
        variableouty = U2.CreateVariables1(1,"y")
        variableoutz = U2.CreateVariables1(1,"z")
        variableoutw = U2.CreateVariables1(1,"w")

        #variablev1 = U2.CreateVariables2(0,1,"v")
        #variablev2 = U2.CreateVariables2(0,1,"v")

        if self.Round == 1:
            self.round_function_constraints(1,variableinx,variableiny,variableinz,variableinw,variableoutx,variableouty,variableoutz,variableoutw)   #产生圈函数算法的约束条件，包含四圈的S盒与P盒
        else :
            self.round_function_constraints(1,variableinx,variableiny,variableinz,variableinw,variableoutx,variableouty,variableoutz,variableoutw)   #产生圈函数算法的约束条件，包含四圈的S盒与P盒
            for i in range(1,self.Round):
                variableinx,variableiny,variableinz,variableinw = U2.LinearLayer(variableoutx,variableouty,variableoutz,variableoutw)     #产生大置换的约束条件、
                variableoutx = U2.CreateVariables1(i+1,"x")           #创造第i+1圈的变元
                variableouty = U2.CreateVariables1(i+1,"y")
                variableoutz = U2.CreateVariables1(i+1,"z")
                variableoutw = U2.CreateVariables1(i+1,"w")
                self.round_function_constraints(i+1,variableinx,variableiny,variableinz,variableinw,variableoutx,variableouty,variableoutz,variableoutw)

    def Init(self):                                        # 设置初始可分性
        variableinx = U2.CreateVariables1(0,"x")           #创造第0圈的变元
        variableiny = U2.CreateVariables1(0,"y")
        variableinz = U2.CreateVariables1(0,"z")
        variableinw = U2.CreateVariables1(0,"w")

        fileobj = open(self.filename_model,"a")

        for i in range(14):
            fileobj.write(variableinx[i] + " = 1")
            fileobj.write("\n")
        for i in range(14,15):
            fileobj.write(variableinx[i] + " = 1")
            fileobj.write("\n")
        for i in range(15,16):
            fileobj.write(variableinx[i] + " = 1")
            fileobj.write("\n")


        for i in range(1):
            fileobj.write(variableiny[i] + " = 1")
            fileobj.write("\n")
        for i in range(1,15):
            fileobj.write(variableiny[i] + " = 1")
            fileobj.write("\n")
        for i in range(15,16):
            fileobj.write(variableiny[i] + " = 1")
            fileobj.write("\n")


        for i in range(13):
            fileobj.write(variableinz[i] + " = 0")
            fileobj.write("\n")
        for i in range(13,14):
            fileobj.write(variableinz[i] + " = 0")
            fileobj.write("\n")
        for i in range(14,16):
            fileobj.write(variableinz[i] + " = 0")
            fileobj.write("\n")


        for i in range(1):
            fileobj.write(variableinw[i] + " = 1")
            fileobj.write("\n")
        for i in range(1,16):
            fileobj.write(variableinw[i] + " = 1")
            fileobj.write("\n")
        fileobj.close()

    def VariableBinary(self):   #设置所有变元为二元变量
        fileobj = open(self.filename_model,"a")
        fileobj.write("Binary\n")

        for i in range(self.Round+1):
            for j in range(16):
                fileobj.write("x_" + str(i) + "_" + str(j))
                fileobj.write("\n")

            for j in range(16):
                fileobj.write("y_" + str(i) + "_" + str(j))
                fileobj.write("\n")

            for j in range(16):
                fileobj.write("z_" + str(i) + "_" + str(j))
                fileobj.write("\n")

            for j in range(16):
                fileobj.write("w_" + str(i) + "_" + str(j))
                fileobj.write("\n")
            
        for i in range(1,self.Round+1):
            for j in range(5):
                for k in range(16):
                    fileobj.write("u_" + str(i) + "_" + str(j) + "_" + str(k) )
                    fileobj.write("\n")
        for i in range(1,self.Round+1):
            for j in range(5):
                for k in range(16):
                    fileobj.write("v_" + str(i) + "_" + str(j) + "_" + str(k) )
                    fileobj.write("\n")

        fileobj.close()



    def MakeModel(self):    #创造u2算法更新Round圈的MILP模型
       	self.Constraint()
       	self.Init()
       	self.VariableBinary()
    
    def WriteObjective(self,obj):  #写入目标函数的某些信息
        fileobj = open(self.filename_result,"a")
        fileobj.write("The objective value = %d\n"%obj.getValue())
        eqn1 = []
        eqn2 = []
        for i in range(0,self.blocksize):
            u = obj.getVar(i)
            if u.getAttr("x") !=0 :
                eqn1.append(u.getAttr( 'VarName') )
                eqn2.append(u.getAttr('x'))
        length = len(eqn1)
        for i in range(0,length):
            s = eqn1[i] + " = " + str( eqn2[i] )
            fileobj.write( s )
            fileobj.write( "\n" )
        fileobj.close()


    def SolveModel( self ):           #求解相应的MILP模型   

        time_start = time.time()
        m = read(self.filename_model)
        counter = 0
        set_zero = []

        while ( counter < self.blocksize ):
            m.optimize()
            if m.Status == 2 :      #Status == 2说明模型可解
                obj = m.getObjective()
                if obj.getValue() > 1:
                    print("模型可解，目标值大于1，说明找到了区分器")
                    break
                else :
                    fileobj = open(self.filename_result,"a")
                    fileobj.write("COUNTER = %d\n"%counter)
                    fileobj.close()
                    self.WriteObjective(obj)       
                    for i in range(0,self.blocksize):
                        u = obj.getVar(i)
                        temp = u.getAttr('x')
                        if temp == 1:
                            set_zero.append(u.getAttr('VarName'))
                            u.ub = 0
                            m.update()
                            counter += 1
                            break
            elif m.Status == 3:
                print("模型不可解，说明找到了区分器")
                break 
            else :
                print("Unkonwn error!")
                break

        fileobj = open(self.filename_result,"a")
        fileobj.write("Those are the coordinates set to zero: \n")
        for u in set_zero:
            fileobj.write( u )
            fileobj.write("\n")

        fileobj.write("\n")

        time_end = time.time()
        fileobj.write(("Time used =" + str(time_end - time_start)))
        fileobj.close()
        


